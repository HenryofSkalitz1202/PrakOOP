#include "PlasticCup.hpp"

bool PlasticCup::is_usable()
{
  return Plastic::is_usable() && maximum_microplastics > current_microplastics;
}

void PlasticCup::fill(int volume, enum WaterType type)
{
  if (PlasticCup::is_usable())
  {
    Cup::fill(volume, type);
    Plastic::use();
    current_microplastics += type == 1 ? 2 * Plastic::shred_microplastics(Cup::get_water_volume(), capacity) : Plastic::shred_microplastics(Cup::get_water_volume(), capacity);
  }
}

void PlasticCup::drink(int volume)
{
  if (PlasticCup::is_usable())
  {
    Cup::drink(volume);
    Plastic::use();
    current_microplastics -= volume;
    if (current_microplastics < 0) {
        current_microplastics = 0;
    }
  }
}

void PlasticCup::drop(int height)
{
  if (PlasticCup::is_usable())
  {
    current_microplastics += Plastic::shred_microplastics(Cup::get_water_volume() * height, capacity);
  }
}