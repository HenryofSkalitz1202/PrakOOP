#include "GlassCup.hpp"

bool GlassCup::is_usable()
{
  return Glass::is_usable();
}

void GlassCup::fill(int volume, enum WaterType type)
{
    if (GlassCup::is_usable()) {
        Cup::fill(volume, type);

    }
}

void GlassCup::drink(int volume)
{
    if (GlassCup::is_usable()) {
        Cup::drink(volume);
    }
}

void GlassCup::drop(int height)
{
    if (GlassCup::is_usable()) {
        Glass::apply_force(height * Cup::get_water_volume());
        if (Cup::get_water_volume() == 0) {
            Glass::apply_force(height);
        }
    }
}