public class InvalidEmailDomainException extends Exception {
    public InvalidEmailDomainException() {
        super("Invalid Email Domain!");
    }
}
