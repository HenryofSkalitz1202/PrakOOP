public class InvalidEmailUserException extends Exception {
    public InvalidEmailUserException() {
        super("Invalid Email User!");
    }
}
