/**
 * InvalidCountryException
 */
public class InvalidCountryException extends Exception {
    public InvalidCountryException() {
        super("Invalid Country Code!");
    }
}