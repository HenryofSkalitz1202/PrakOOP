public class InvalidPhoneLengthException extends Exception{
    public InvalidPhoneLengthException() {
        super("Invalid Phone Length!");
    }
}
