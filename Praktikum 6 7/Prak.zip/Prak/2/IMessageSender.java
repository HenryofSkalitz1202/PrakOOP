
public interface IMessageSender {
    void sendMessage(User data, String message);
}